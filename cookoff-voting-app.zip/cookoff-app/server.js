"use strict";
// Cook-Off Voting server. No packages to install: it only uses what ships with Node.
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || __dirname;
const DATA_FILE = path.join(DATA_DIR, "data.json");
const PUBLIC_DIR = path.join(__dirname, "public");

let ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
if (!ADMIN_PASSWORD) {
  ADMIN_PASSWORD = crypto.randomBytes(4).toString("hex");
  console.log("\nNo ADMIN_PASSWORD was set, so one was made up for this run.");
  console.log("Host password: " + ADMIN_PASSWORD + "\n");
}

// ---------- storage ----------
let db = { config: { categories: [], open: true }, ballots: {} };
try {
  const loaded = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  if (loaded && loaded.config && loaded.ballots) db = loaded;
} catch (e) { /* first run: start empty */ }

function save() {
  const tmp = DATA_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(db));
  fs.renameSync(tmp, DATA_FILE);
}

// ---------- helpers ----------
const slug = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "x";
const entryKey = (catId, name) => catId + ":" + slug(name);
const NAME_RE = /^[\p{L}'’\-]{1,20}$/u;
const VOTER_RE = /^[A-Za-z0-9_-]{16,64}$/;
const CAT_ID_RE = /^[a-z0-9]{3,12}$/;

function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on("data", (c) => {
      size += c.length;
      if (size > 2 * 1024 * 1024) { reject(new Error("too large")); req.destroy(); return; }
      chunks.push(c);
    });
    req.on("end", () => {
      try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString("utf8")) : {}); }
      catch (e) { reject(new Error("bad json")); }
    });
    req.on("error", reject);
  });
}

function sha(s) { return crypto.createHash("sha256").update(String(s)).digest(); }
function passwordOk(candidate) { return crypto.timingSafeEqual(sha(candidate || ""), sha(ADMIN_PASSWORD)); }

const fails = new Map(); // ip -> [timestamps]
function clientIp(req) {
  const fwd = req.headers["x-forwarded-for"];
  return (fwd ? String(fwd).split(",")[0].trim() : req.socket.remoteAddress) || "unknown";
}
function tooManyFails(ip) {
  const now = Date.now();
  const list = (fails.get(ip) || []).filter((t) => now - t < 10 * 60 * 1000);
  fails.set(ip, list);
  return list.length >= 10;
}

function requireAdmin(req, res) {
  const ip = clientIp(req);
  if (tooManyFails(ip)) { send(res, 429, { error: "Too many wrong passwords. Wait 10 minutes." }); return false; }
  if (!passwordOk(req.headers["x-admin-password"])) {
    fails.get(ip).push(Date.now());
    send(res, 401, { error: "Wrong password." });
    return false;
  }
  return true;
}

function cleanConfig(input) {
  if (!input || !Array.isArray(input.categories) || input.categories.length > 30) return null;
  const categories = [];
  for (const c of input.categories) {
    if (!c || !CAT_ID_RE.test(String(c.id))) return null;
    const name = String(c.name || "").trim().slice(0, 40);
    const entries = [];
    const seen = new Set();
    for (const e of Array.isArray(c.entries) ? c.entries.slice(0, 60) : []) {
      const n = String(e).trim().slice(0, 40);
      if (!n || seen.has(slug(n))) continue;
      seen.add(slug(n));
      entries.push(n);
    }
    categories.push({ id: String(c.id), name, entries });
  }
  return { categories, open: input.open !== false };
}

// ---------- API ----------
async function handleApi(req, res, url) {
  const route = req.method + " " + url.pathname;
  try {
    if (route === "GET /api/config") {
      return send(res, 200, { categories: db.config.categories, open: db.config.open });
    }

    if (route === "GET /api/mine") {
      const id = req.headers["x-voter-id"];
      if (!VOTER_RE.test(String(id || ""))) return send(res, 200, { ballot: null });
      return send(res, 200, { ballot: db.ballots[id] || null });
    }

    if (route === "POST /api/vote") {
      const body = await readBody(req);
      if (!db.config.open) return send(res, 403, { error: "Voting is closed." });
      if (!VOTER_RE.test(String(body.voterId || ""))) return send(res, 400, { error: "Reload the page and try again." });
      const name = String(body.name || "").trim();
      if (!NAME_RE.test(name)) return send(res, 400, { error: "Enter your first name only, with no spaces or last name." });
      const valid = new Set();
      db.config.categories.forEach((c) => c.entries.forEach((n) => valid.add(entryKey(c.id, n))));
      const ratings = {};
      let count = 0;
      const given = body.ratings && typeof body.ratings === "object" ? body.ratings : {};
      for (const k of Object.keys(given)) {
        const v = Number(given[k]);
        if (valid.has(k) && (v === 1 || v === 2 || v === 3)) { ratings[k] = v; count++; }
      }
      if (!count) return send(res, 400, { error: "Rate at least one cook before you submit." });
      if (!db.ballots[body.voterId] && Object.keys(db.ballots).length >= 5000) return send(res, 507, { error: "Ballot box is full." });
      db.ballots[body.voterId] = { name, ratings, ts: Date.now() };
      save();
      return send(res, 200, { ok: true });
    }

    if (route === "POST /api/admin/check") {
      if (!requireAdmin(req, res)) return;
      return send(res, 200, { ok: true });
    }

    if (route === "GET /api/admin/results") {
      if (!requireAdmin(req, res)) return;
      const ballots = Object.values(db.ballots).map((b) => ({ name: b.name, ratings: b.ratings, ts: b.ts }));
      return send(res, 200, { ballots });
    }

    if (route === "PUT /api/admin/config") {
      if (!requireAdmin(req, res)) return;
      const next = cleanConfig(await readBody(req));
      if (!next) return send(res, 400, { error: "That setup could not be saved." });
      db.config = next;
      save();
      return send(res, 200, { ok: true, config: next });
    }

    if (route === "GET /api/admin/backup") {
      if (!requireAdmin(req, res)) return;
      return send(res, 200, { version: 1, config: db.config, ballots: db.ballots });
    }

    if (route === "POST /api/admin/restore") {
      if (!requireAdmin(req, res)) return;
      const body = await readBody(req);
      const cfg = cleanConfig(body.config);
      if (!cfg || !body.ballots || typeof body.ballots !== "object" || Array.isArray(body.ballots)) {
        return send(res, 400, { error: "That file is not a backup from this app." });
      }
      const ballots = {};
      for (const id of Object.keys(body.ballots).slice(0, 5000)) {
        const b = body.ballots[id];
        if (!VOTER_RE.test(id) || !b || !NAME_RE.test(String(b.name || ""))) continue;
        const ratings = {};
        for (const k of Object.keys(b.ratings || {}).slice(0, 2000)) {
          const v = Number(b.ratings[k]);
          if (k.length <= 80 && (v === 1 || v === 2 || v === 3)) ratings[k] = v;
        }
        ballots[id] = { name: String(b.name), ratings, ts: Number(b.ts) || Date.now() };
      }
      db = { config: cfg, ballots };
      save();
      return send(res, 200, { ok: true, config: cfg, count: Object.keys(ballots).length });
    }

    if (route === "POST /api/admin/reset") {
      if (!requireAdmin(req, res)) return;
      db.ballots = {};
      save();
      return send(res, 200, { ok: true });
    }

    return send(res, 404, { error: "Not found." });
  } catch (e) {
    return send(res, e.message === "too large" ? 413 : 400, { error: "That request could not be read." });
  }
}

// ---------- static files ----------
const TYPES = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml", ".ico": "image/x-icon" };

function serveStatic(req, res, url) {
  let rel = decodeURIComponent(url.pathname);
  if (rel === "/") rel = "/index.html";
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) { res.writeHead(403); return res.end("Forbidden"); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { "Content-Type": "text/plain" }); return res.end("Not found"); }
    res.writeHead(200, { "Content-Type": TYPES[path.extname(file)] || "application/octet-stream", "Cache-Control": "no-cache" });
    res.end(data);
  });
}

http.createServer((req, res) => {
  const url = new URL(req.url, "http://localhost");
  if (url.pathname === "/healthz") { res.writeHead(200); return res.end("ok"); }
  if (url.pathname.startsWith("/api/")) return handleApi(req, res, url);
  if (req.method !== "GET" && req.method !== "HEAD") { res.writeHead(405); return res.end(); }
  return serveStatic(req, res, url);
}).listen(PORT, () => {
  console.log("Cook-Off Voting is running on port " + PORT);
});
