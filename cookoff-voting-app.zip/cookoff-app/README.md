# Cook-Off Voting

A scan-to-vote ballot. Guests scan a QR code, type a first name, and rate each cook 1 to 3 (3 is the favorite). No accounts, no sign-in. You, the host, set up categories, watch the tally, and show the QR code.

## What is in this folder

- `server.js` the program that saves votes
- `public/index.html` the page voters and the host see
- `public/qrcode.js` makes the QR code
- `package.json` tells hosting sites how to start it

There is nothing to install. It only needs Node 18 or newer.

## Option A: try it on your own computer first

1. Install Node from nodejs.org (the "LTS" download).
2. Open a terminal in this folder and run:

   Mac or Linux: `ADMIN_PASSWORD=pick-a-password npm start`

   Windows (PowerShell): `$env:ADMIN_PASSWORD="pick-a-password"; npm start`

3. Open http://localhost:3000 in your browser.
4. Click **Host login** at the bottom, enter your password, and add categories in **Setup**.

This works on your computer only. To let any phone vote, use Option B.

## Option B: put it online so any phone can vote (Render, free)

You need a free GitHub account and a free Render account.

1. On github.com click **New repository**, name it `cookoff`, and create it.
2. On the new repository page click **uploading an existing file**. Drag in everything from this folder (including the `public` folder) and click **Commit changes**.
3. On render.com click **New > Web Service** and connect your `cookoff` repository.
4. Fill in:
   - Language: **Node**
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Instance type: **Free**
5. Under **Environment Variables** add `ADMIN_PASSWORD` with the password you want for the host login.
6. Click **Deploy**. When it finishes, Render shows your address, something like `https://cookoff-abcd.onrender.com`.
7. Open that address, click **Host login**, set up your categories, then open the **QR code** tab. The code already points to your address. Show it on a screen or print it.

## Important: free hosting can erase votes

On Render's free plan the saved votes are wiped whenever the site restarts, redeploys, or sits idle for 15 minutes. After idle it takes about a minute to wake up. Render also may restart it at any time.

What to do:

- Set up your categories shortly before the event, and open the site once a few minutes before guests arrive.
- During the event, open **Results > Download backup** every so often. If votes ever disappear, use **Restore from backup** in the same place.
- For something you do not have to watch, use a paid Render instance with a persistent disk. Add an environment variable `DATA_DIR` set to the disk's mount path, for example `/var/data`.

## How votes work

- Each phone gets one ballot. Submitting again replaces its earlier ballot.
- A person who clears their browser data or uses another phone can vote again. This is meant for a friendly event, not for a strict election.
- First names only. Names with spaces, numbers or symbols are rejected.
- Ratings add up per cook. The Results tab shows the total, the average, and how many 3s each cook got.
- **Close voting** in the Setup tab stops new votes. **Reset all votes** in the Results tab clears everything.
